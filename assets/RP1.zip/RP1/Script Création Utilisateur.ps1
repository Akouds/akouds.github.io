﻿# Demande à l'utilisateur les informations nécessaires pour créer l'utilisateur
$nom = Read-Host "Entrez le nom de l'utilisateur"
$prenom = Read-Host "Entrez le prénom de l'utilisateur"
$nomSession = Read-Host "Entrez le nom d'ouverture à la session de l'utilisateur"
$motDePasse = Read-Host "Entrez le mot de passe de l'utilisateur" -AsSecureString

# Récupération de la liste des groupes disponibles dans Active Directory
$listeGroupes = Get-ADGroup -Filter * | Select-Object -ExpandProperty Name

# Affichage de la liste des groupes et demande de choix à l'utilisateur
Write-Host "Groupes disponibles dans Active Directory :"
for ($i = 0; $i -lt $listeGroupes.Count; $i++) {
    Write-Host "$($i+1). $($listeGroupes[$i])"
}
$choix = Read-Host "Entrez le numéro correspondant au groupe dans lequel ajouter l'utilisateur"

# Vérification du choix de l'utilisateur
if ($choix -ge 1 -and $choix -le $listeGroupes.Count) {
    $nomGroupe = $listeGroupes[$choix - 1]

    # Création de l'utilisateur dans Active Directory
    $userParams = @{
        Name = "$prenom $nom"
        GivenName = $prenom
        Surname = $nom
        SamAccountName = $nomSession
        AccountPassword = $motDePasse
        Enabled = $true
    }

    New-ADUser @userParams

    # Recherche du groupe dans Active Directory
    $groupe = Get-ADGroup -Filter { Name -eq $nomGroupe }

    # Ajout de l'utilisateur au groupe spécifié
    Add-ADGroupMember -Identity $groupe -Members $nomSession

    Write-Host "L'utilisateur $prenom $nom avec le nom d'ouverture à la session $nomSession a été créé avec succès et ajouté au groupe $($groupe.Name) situé à $($groupe.DistinguishedName)."
} else {
    Write-Host "Choix invalide. Veuillez choisir un numéro valide correspondant à un groupe."
}
