﻿# Fonction pour afficher la liste des groupes disponibles dans Active Directory
function AfficherListeGroupes {
    $listeGroupes = Get-ADGroup -Filter * | Select-Object -ExpandProperty Name
    Write-Host "Groupes disponibles dans Active Directory :"
    for ($i = 0; $i -lt $listeGroupes.Count; $i++) {
        Write-Host "$($i+1). $($listeGroupes[$i])"
    }
}

# Demande à l'utilisateur le nom de l'utilisateur à modifier
$nomUtilisateur = Read-Host "Entrez le nom de l'utilisateur à modifier"

# Vérification de l'existence de l'utilisateur dans Active Directory
try {
    $utilisateur = Get-ADUser -Identity $nomUtilisateur -ErrorAction Stop
} catch {
    Write-Host "Utilisateur $nomUtilisateur non trouvé dans Active Directory."
    exit
}

# Affichage des propriétés actuelles de l'utilisateur
Write-Host "Propriétés actuelles de l'utilisateur :"
Write-Host "Nom complet : $($utilisateur.Name)"
Write-Host "Nom d'ouverture à la session : $($utilisateur.SamAccountName)"
Write-Host "Prénom : $($utilisateur.GivenName)"
Write-Host "Nom : $($utilisateur.Surname)"
Write-Host "Groupes : $($utilisateur.MemberOf -join ', ')"

# Demande à l'utilisateur les nouvelles informations pour l'utilisateur
$newNom = Read-Host "Entrez le nouveau nom de l'utilisateur (laissez vide pour conserver l'actuel)"
$newPrenom = Read-Host "Entrez le nouveau prénom de l'utilisateur (laissez vide pour conserver l'actuel)"
$newNomSession = Read-Host "Entrez le nouveau nom d'ouverture à la session de l'utilisateur (laissez vide pour conserver l'actuel)"

# Afficher la liste des groupes et demander à l'utilisateur de choisir un nouveau groupe
AfficherListeGroupes
$choixGroupe = Read-Host "Entrez le numéro correspondant au nouveau groupe pour l'utilisateur (laissez vide pour conserver les groupes actuels)"

# Vérification du choix de l'utilisateur pour le groupe
if ($choixGroupe -ge 1 -and $choixGroupe -le $listeGroupes.Count) {
    $newGroupe = $listeGroupes[$choixGroupe - 1]
} else {
    Write-Host "Choix invalide. Les groupes actuels seront conservés."
    $newGroupe = $utilisateur.MemberOf
}

# Modification de l'utilisateur dans Active Directory avec les nouvelles informations
Set-ADUser -Identity $utilisateur -GivenName $newPrenom -Surname $newNom -SamAccountName $newNomSession

# Supprimer l'utilisateur des anciens groupes
foreach ($group in $utilisateur.MemberOf) {
    Remove-ADGroupMember -Identity $group -Members $utilisateur -Confirm:$false
}

# Ajouter l'utilisateur au nouveau groupe
Add-ADGroupMember -Identity $newGroupe -Members $utilisateur -Confirm:$false

Write-Host "L'utilisateur $newPrenom $newNom a été modifié avec succès. Nouveau groupe : $newGroupe."
