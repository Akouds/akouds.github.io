﻿# Demande à l'utilisateur le nom d'ouverture de session de l'utilisateur à supprimer
$nomUtilisateur = Read-Host "Entrez le nom d'ouverture de session de l'utilisateur à supprimer"

# Vérification de l'existence de l'utilisateur dans Active Directory
try {
    $utilisateur = Get-ADUser -Identity $nomUtilisateur -ErrorAction Stop
} catch {
    Write-Host "Utilisateur $nomUtilisateur non trouvé dans Active Directory."
    exit
}

# Confirmation de la suppression de l'utilisateur
$confirmation = Read-Host "Voulez-vous vraiment supprimer l'utilisateur $($utilisateur.SamAccountName) ? (O/N)"

if ($confirmation -eq "O" -or $confirmation -eq "o") {
    # Suppression de l'utilisateur
    Remove-ADUser -Identity $utilisateur -Confirm:$false
    Write-Host "L'utilisateur $($utilisateur.SamAccountName) a été supprimé avec succès."
} else {
    Write-Host "La suppression de l'utilisateur a été annulée."
}
